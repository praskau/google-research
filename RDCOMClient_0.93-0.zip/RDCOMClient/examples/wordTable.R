if(FALSE) {
w = COMCreate("Word.Application")
d = w[["Documents"]]$Add()
}

data(mtcars)

